package mx.edu.ittepic.dadm_proyectofinal;


public interface AsyncResponse {
    void procesarRespuesta(String r);
}