package mx.edu.ittepic.dadm_proyectofinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class sabiasque extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sabiasque);
    }
}
